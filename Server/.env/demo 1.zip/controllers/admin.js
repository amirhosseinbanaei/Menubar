const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

const Admin = require("../models/adminModel");
const Project = require('../models/projectModel');

const signToken = (userId, secretKey, expireTime) => {
   return jwt.sign({ userId }, process.env[secretKey], { expiresIn: `${expireTime}` });
}

exports.register = async (req, res) => {
   const { fullName, projectName, projectNameFa, projectId, domain, languages, email, phoneNumber, password, plan, role } = req.body;

   try {
      const hashedPassword = await bcrypt.hash(password, 10);
      const admin = await Admin.create({
         fullName,
         email,
         phoneNumber,
         password: hashedPassword,
         projectName,
         projectNameFa,
         projectId,
         plan,
         role,
         domain,
         languages
      });

      const accessToken = signToken(admin._id, 'JWT_SECRET_ACCESSTOKEN', '1d');
      const refreshToken = signToken(admin._id, 'JWT_SECRET_REFRESHTOKEN', '7d');

      res.cookie('accessToken', accessToken, { httpOnly: true, expire: '1d' });
      res.cookie('refreshToken', refreshToken, { httpOnly: true, expire: '2d' });

      return res.status(201).json({ status: 'success', message: 'ادمین جدید اضافه شد .' });
   } catch (error) {
      return res.status(500).json({ status: 'failed', message: 'در فرآیند ثبت نام خطایی رخ داد !', error });
   }
};

exports.login = async (req, res) => {
   const { email, password } = req.body;

   const admin = await Admin.findOne({ email }).populate('projectId');

   if (!admin) {
      return res.status(401).json({ message: "کاربری با این نام کاربری وجود ندارد" });
   }

   const isPasswordValid = await bcrypt.compare(password, admin.password);

   if (!isPasswordValid) {
      return res.status(401).json({ message: "پسورد وارد شده صحیح نیست" });
   }
   const adminObject = admin.toObject();
   const projectData = await Project.findOne({ name: adminObject.projectName })
   Reflect.deleteProperty(adminObject, "password");
   Reflect.deleteProperty(adminObject, "phoneNumber");

   const accessToken = signToken(admin._id, 'JWT_SECRET_ACCESSTOKEN', '1d');
   const refreshToken = signToken(admin._id, 'JWT_SECRET_REFRESHTOKEN', '2d');

   res.cookie('accessToken', accessToken);
   res.cookie('refreshToken', refreshToken);

   return res.json({ userData: adminObject, projectData });
};