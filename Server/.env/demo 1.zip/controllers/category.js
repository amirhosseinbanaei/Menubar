const fs = require('fs');
const path = require('path');
const Category = require('./../models/categoryModel');
const multerStorage = require('./../utils/multerStorage');
// const ftpDeleteHandler = require('./../middlewares/ftpUpload');

const upload = multerStorage('category');
exports.upload = upload.single('category-image');

exports.getCategory = async (req, res) => {
   const category = await Category.findById(req.params.categoryId);
   if (!category) {
      return res.status(404).json({ status: 'failed', message: "دسته بندی یافت نشد !" });
   }
   return res.status(200).json(category);
};

exports.getCategories = async (req, res) => {
   const categories = await Category.find({ project: req.headers.project });
   res
      .status(200)
      .json(categories)
};

exports.createCategory = async (req, res) => {
   // if (req.file && req.resizedImagePath) {
   //    fs.rm(path.join(__dirname, `../uploads/category/${req.file.originalname}`), err => {
   //       if (err) {
   //          console.log(err)
   //       }
   //    });
   //    fs.rm(`${req.resizedImagePath}`, err => err && console.log(err));
   // }
   try {
      const language = req.body.language.split(',');
      const newCategory = {
         image: req.body.imageId ? `${req.body.domain}/assets/images/${req.body.imageId}.jpeg` : `${req.body.domain}/assets/images/no-preview.png`,
         subCategory: req.body.subCategory,
         project: req.headers.project,
      };
      if (language.length === 1) {
         newCategory[language] = {
            name: req.body[`${language}Name`],
         };
      } else {
         language.forEach(eachLanguage => {
            newCategory[eachLanguage] = {
               name: req.body[`${eachLanguage}Name`],
            };
         })
      }
      await Category.create(newCategory);

      res
         .status(201)
         .json({
            status: "success",
            message: "دسته بندی با موفقیت ایجاد شد"
         })
   } catch (err) {
      console.log(err)
      res
         .status(404)
         .json({
            status: "failed",
            message: "ساخت دسته بندی با مشکل مواجه شد"
         })
   }
};

exports.editCategory = async (req, res) => {
   try {
      const categoryId = req.params.categoryId;
      const category = await Category.findById(categoryId);

      if (!category) {
         return res.status(404).json({ message: 'Item not found' });
      }

      const bodyKeys = Object.keys(req.body);
      if (bodyKeys.length > 1) {
         bodyKeys.forEach(eachKey => {
            category[eachKey] = req.body[eachKey];
         })
      } else {
         category[bodyKeys] = req.body[bodyKeys];
      }
      category.save();
      // console.log(bodyKeys);
      // const updatedFields = {};
      // bodyKeys.forEach(key => {
      //    if (key !== 'image') {
      //       updatedFields[key] = req.body[key];
      //    } else {
      //       updatedFields[key] = `${req.body.domain}/assets/images/${req.body[key]}.jpeg`
      //    }
      // })
      // if (req.finalImageName) {
      //    updatedFields['image'] = `https://ftp-menubar.amirhosseinbanaei.ir/admin-ftp-menubar${req.finalImageName}`
      // }
      // const updatedCategory = await Category.findByIdAndUpdate(
      //    categoryId,
      //    { $set: updatedFields },
      //    { new: true } // Return the updated document
      // );

      return res.status(200).json({ message: 'Category updated successfully' });
   } catch (error) {
      console.error(error);
      res.status(500).json({ message: 'An error occurred' });
   }
};

exports.deleteCategory = async (req, res) => {
   const deleteCategory = await Category.findByIdAndDelete(req.params.categoryId);
   if (!deleteCategory) {
      return res.status(404).json({ status: 'failed', message: "دسته بندی یافت نشد !" });
   }
   return res.status(200).json({ status: 'success', message: "دسته بندی با موفقیت حذف شد!" });
};

exports.deleteSubCategory = async (req, res) => {
   try {
      const { categoryId, subCategoryId } = req.query;
      const currentCategory = await Category.findById(categoryId);
      const filtered = currentCategory.subCategory.filter(el => el.id !== subCategoryId);
      currentCategory.subCategory = filtered;
      currentCategory.save();
      return res.status(200).json({ status: 'success', message: "Subcategory deleted successfully" });
   } catch (error) {
      console.log(error);
      return res.status(400).json({ status: 'failed', message: "Subcategory couldn't delete" });
   }
};