const JalaliMoment = require('jalali-moment');



const Payment = require('./../models/paymentModel');
const Order = require('./../models/orderModel');

const ZarinpalCheckout = require('zarinpal-checkout');
const zarinpal = ZarinpalCheckout.create('00000000-0000-0000-0000-000000000000', true);

const projects = [];

exports.checkout = async (req, res) => {
   const { amount, items, userId, projectId, type, isCash } = req.body;
   // const findPayment = await Payment.findOne({ projectId });
   zarinpal.PaymentRequest({
      Amount: amount,
      CallbackURL: 'http://localhost:6001/api/checkout/check',
      Description: 'A Payment from Node.JS',
      Email: 'hi@siamak.work',
      Mobile: '09120000000'
   }).then(response => {
      if (response.status === 100) {
         const jalaliCurrentDateTime = new JalaliMoment();
         const iranCurrentDate = jalaliCurrentDateTime.format('jYYYY-jMM-jDD HH:mm:ss');
         Order.create({ items, amount, createdAt: iranCurrentDate, authority: response.authority, userId, projectId, type, isCash });
         const currentProject = {
            authority: response.authority,
            project: req.headers.project,
            origin: req.headers.origin
         };
         projects.push(currentProject);
         return res.status(200).json(response.url);
      }
   }).catch(error => {
      return res.status(404).json({
         message: 'خطایی در اتصال به درگاه پرداخت پیش آمد',
         error
      })
   });
}

exports.checkCheckout = async (req, res) => {
   const { Authority, Status } = req.query;
   const currentOrder = await Order.findOne({ authority: Authority });
   const currentProjectIndex = projects.findIndex(eachProject => eachProject.authority === Authority);
   if (Status === 'OK') {
      currentOrder.status = true;
      await currentOrder.save();
      return res.redirect(`${projects[currentProjectIndex]['origin']}/checkout/success?authority=${Authority}`);
   } else {
      return res.redirect(`${projects[currentProjectIndex]['origin']}/checkout/failed?authority=${Authority}`);
   }
}