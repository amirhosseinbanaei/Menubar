const fs = require('fs');
const xlsx = require('xlsx');
const path = require('path');
const Item = require('./../models/itemModel');
const multerStorage = require('./../utils/multerStorage');
const ftpDeleteHandler = require('./../middlewares/ftpUpload');
const upload = multerStorage('item');
const uploadExcel = multerStorage('excel files');

exports.upload = upload.single('item-image');
exports.uploadExcel = uploadExcel.single('excel-file');

exports.getItems = async (req, res) => {
   const project = req.headers.project;
   const getItem = await Item.find({ project }).populate('category');
   if (!getItem) {
      return res.status(404).json({ status: 'failed', message: 'Item not found' });
   }
   return res.status(200).json(getItem);
};

exports.getSingleItem = async (req, res) => {
   const itemId = req.params.itemId
   const item = await Item.findById(itemId).populate('category');
   if (!item) {
      return res.status(404).json({ status: 'failed', message: 'Item not found' });
   }
   return res.status(200).json(item);
};

exports.addItem = async (req, res) => {
   try {
      const language = req.body.language.split(',');
      const newItem = {
         image: req.body.imageId ? `${req.body.domain}/assets/images/${req.body.imageId}.jpeg` : `${req.body.domain}/assets/images/no-preview.png`,
         category: req.body.category,
         available: true,
         hideItem: false,
         price: req.body.price || 0,
         tags: req.body.tags,
         subCategory: req.body.subCategory,
         project: req.headers.project
      };

      if (language.length === 1) {
         newItem[language] = {
            name: req.body[`${language}Name`],
            cardDescription: req.body[`${language}CardDescription`],
         };
      } else {
         language.forEach(eachLanguage => {
            newItem[eachLanguage] = {
               name: req.body[`${eachLanguage}Name`],
               cardDescription: req.body[`${eachLanguage}CardDescription`],
            };
         })
      }

      await Item.create(newItem);
      res
         .status(201)
         .json({
            status: "success",
            message: "آیتم جدید با موفقیت ایجاد شد"
         })
   } catch (err) {
      console.log(err)
      res
         .status(404)
         .json({
            status: "failed",
            message: "ساخت آیتم با مشکل مواجه شد !"
         })
   }
};

exports.addItemWithExcel = async (req, res) => {
   const excelPath = path.join(__dirname, '..', `/uploads/excel files/${req.file.originalname}`)
   console.log(excelPath)
   const workbook = xlsx.readFile(excelPath);
   const sheetName = workbook.SheetNames[0];
   const sheet = workbook.Sheets[sheetName];
   const data = xlsx.utils.sheet_to_json(sheet);
   console.log(data)
}


exports.editItemOld = async (req, res) => {
   if (req.file && req.resizedImagePath) {
      fs.rm(path.join(__dirname, `../../upload/food/${req.file.originalname}`), err => {
         if (err) {
            console.log(err)
         }
      });
      fs.rm(`${req.resizedImagePath}`, err => err && console.log(err));
   }
   const item = await Item.findOne({
      _id: req.body.id,
      project: req.headers.project
   }).populate('category');
   if (!item) {
      return res.status(404).json({ status: 'failed', message: "غذا یافت نشد !" });
   }
   if (req.finalImageName) {
      ftpDeleteHandler(item.image)
   }
   const updateData = {
      image: req.finalImageName ? `https://ftp-menubar.amirhosseinbanaei.ir/admin-ftp-menubar${req.finalImageName}` : item.image,
      name: req.body.name ? req.body.name : item.name,
      category: req.body.category ? req.body.category : food.category,
      price: req.body.price ? req.body.price : food.price,
      cardDescription: req.body.cardDescription ? req.body.cardDescription : food.cardDescription,
      description: req.body.description ? req.body.description : food.description,
   }
   try {
      await Food.findOneAndUpdate({ _id: req.body.id, restaurantName: req.headers.restaurantname }, updateData);
      return res.status(200).json({ status: 'success', message: "غذا با موفقیت ویرایش شد ." });
   } catch (error) {
      return res.status(404).json({ status: 'failed', message: "ویرایش غذا با خطا مواجه شد !" });
   }
};

exports.editItem = async (req, res) => {
   try {
      const itemId = req.params.itemId;
      const item = await Item.findById(itemId);
      const bodyKeys = Object.keys(req.body);
      if (bodyKeys.length > 1) {
         bodyKeys.forEach(eachKey => {
            item[eachKey] = req.body[eachKey];
         })
      } else {
         item[bodyKeys] = req.body[bodyKeys];
      }
      item.save();
      return res.status(200).json({ message: 'Item updated successfully' });
   } catch (error) {
      console.error(error);
      res.status(500).json({ message: 'An error occurred' });
   }
};

exports.deleteItem = async (req, res) => {
   const deleteItem = await Item.findByIdAndDelete(req.params.itemId);
   if (!deleteItem) {
      return res.status(404).json({ status: 'failed', message: "آیتم یافت نشد !" });
   }
   return res.status(200).json({ status: 'success', message: "آیتم با موفقیت حذف شد !" });
};

exports.addRating = async (req, res) => {
   const itemId = req.params.itemId;
   const { rating, userId } = req.body;

   try {
      const item = await Item.findById(itemId);

      if (!item) {
         return res.status(404).json({ message: 'Item not found' });
      }

      // Check if the user has already rated this item
      const existingRating = item.ratings.find(
         (r) => r.user.toString() === userId.toString()
      );

      if (existingRating) {
         return res.status(400).json({ message: 'You have already rated this item' });
      }

      // Add the new rating
      item.ratings.push({ user: userId, rating });
      await item.save();
      res.status(200).json({ message: 'Rating added successfully' });
   } catch (error) {
      console.error('Error adding rating:', error);
      res.status(500).json({ message: 'Internal server error' });
   }
}