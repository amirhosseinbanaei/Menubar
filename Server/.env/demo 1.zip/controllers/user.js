const User = require('./../models/userModel');
const jwt = require('jsonwebtoken');

const signToken = (userId, secretKey, expireTime) => {
   return jwt.sign({ userId }, process.env[secretKey], { expiresIn: `${expireTime}` });
}

exports.register = async (phoneNumber, project) => {
   try {
      const newUser = await User.create({
         phoneNumber,
         fullName: 'none',
         email: 'none',
         projects: [{ name: project, orders: 0 }]
      });

      const accessToken = signToken(newUser._id, 'JWT_SECRET_ACCESSTOKEN', '1d');
      const refreshToken = signToken(newUser._id, 'JWT_SECRET_REFRESHTOKEN', '7d');
      return { newUser, accessToken, refreshToken };
   } catch (error) {
      return res.status(500).json({ status: 'failed', message: 'در فرآیند ثبت نام خطایی رخ داد', error });
   }
};

exports.login = async (user) => {
   try {
      const userObject = user.toObject();
      Reflect.deleteProperty(userObject, "phoneNumber");

      const accessToken = signToken(userObject._id, 'JWT_SECRET_ACCESSTOKEN', '1d');
      const refreshToken = signToken(userObject._id, 'JWT_SECRET_REFRESHTOKEN', '7d');

      return { accessToken, refreshToken }
   } catch (error) {
      return res.status(500).json({ status: 'failed', message: 'در فرآیند ورود خطایی رخ داد', error });
   }
};

exports.getUsers = async (req, res) => {
   const { limit, page, startDate, endDate } = req.query;
   const currentPage = page * 1;
   const pageLimit = limit * 1;
   const skip = (currentPage - 1) * pageLimit;
   try {
      let query = { 'projects.name': req.headers.project };
      const aggregationPipeline = [
         { $match: query },
         { $group: { _id: null, count: { $sum: 1 } } }
      ];
      const [totalUsersCount] = await User.aggregate(aggregationPipeline);
      const users = await User.find(query).skip(skip).limit(pageLimit);
      return res.status(200).json({
         totalUsersCount,
         users
      });
   } catch (error) {
      return res.status(404).json('خطایی در دریافت سفارشات پیش آمد');
   }
};

exports.searchUser = async (req, res) => {
   try {
      const { phoneNumber } = req.query;
      console.log(phoneNumber)
      const results = await User.find({ phoneNumber });
      res.status(200).json(results);
   } catch (error) {
      console.error(error);
      res.status(500).json({ error: 'Internal server error' });
   }
}