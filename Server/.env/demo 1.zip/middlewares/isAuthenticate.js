// Middleware to check if the user is authenticated (using the access token)
const jwt = require('jsonwebtoken');
const isAuthenticate = async (req, res, next) => {
   const accessToken = req.cookies.accessToken;
   if (!accessToken) {
      // Access token is not present, user is not logged in
      return res.status(401).json({ message: 'Unauthorized' });
      // return res.redirect('/login');
   }

   try {
      // Verify the access token and extract the user ID
      const decoded = jwt.verify(accessToken, process.env['JWT_SECRET_ACCESSTOKEN']);
      req.userId = decoded.userId;
      next();
   } catch (error) {
      // Access token has expired or is invalid
      // Check if there is a refresh token
      const refreshToken = req.cookies.refreshToken;

      if (!refreshToken) {
         // Refresh token is not present, user is not logged in
         return res.status(401).json({ message: 'Unauthorized' });
         // return res.redirect('/login');
      }

      try {
         // Verify the refresh token
         const decodedRefreshToken = jwt.verify(refreshToken, process.env['JWT_SECRET_REFRESHTOKEN']);

         // If the refresh token is valid, issue a new access token and refresh token and set them in the cookies
         const newAccessToken = jwt.sign({ userId: decodedRefreshToken.userId }, process.env['JWT_SECRET_ACCESSTOKEN'], { expiresIn: '1d' });
         const newRefreshToken = jwt.sign({ userId: decodedRefreshToken.userId }, process.env['JWT_SECRET_REFRESHTOKEN'], { expiresIn: '7d' });

         res.cookie('accessToken', newAccessToken, { httpOnly: true, expire: '1d' });
         res.cookie('refreshToken', newRefreshToken, { httpOnly: true });

         // Continue to the next middleware or route
         req.userId = decodedRefreshToken.userId;
         next();
      } catch (refreshError) {
         // Refresh token has expired or is invalid, user is not logged in
         // return res.redirect('/login');
         return res.status(401).json({ message: 'Unauthorized' });
      }
   }
};
module.exports = isAuthenticate;