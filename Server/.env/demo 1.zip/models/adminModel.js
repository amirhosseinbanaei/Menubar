const mongoose = require('mongoose');
const Schema = new mongoose.Schema({
   fullName: {
      type: String,
      required: true
   },
   projectId: {
      type: String,
      required: true
   },
   email: {
      type: String,
      required: true,
      lowercase: true
   },
   phoneNumber: {
      type: String,
      required: true,
   },
   password: {
      type: String,
      required: true,
   },
   projectName: {
      type: String,
      required: true
   },
   projectNameFa: {
      type: String,
      required: true
   },
   languages: {
      type: Array,
      required: true
   },
   domain: {
      type: String,
      required: true
   },
   plan: {
      type: String,
      required: true
   },
   role: {
      type: String,
      enum: ['ADMIN', 'EDITOR'],
      default: 'ADMIN',
   },
})

const SubmitedAdmin = mongoose.model('admins', Schema);
module.exports = SubmitedAdmin;