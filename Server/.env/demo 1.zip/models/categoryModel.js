const mongoose = require("mongoose");
const translationSchema = new mongoose.Schema({
   name: { type: String, trim: true },
});

const schema = new mongoose.Schema({
   fa: translationSchema,
   en: translationSchema,
   ar: translationSchema,
   subCategory: translationSchema,
   subCategory: {
      type: Array,
   },
   image: {
      type: String,
      required: true,
   },
   project: {
      type: String,
      required: true
   }
}
);

const Category = mongoose.model("categories", schema);

module.exports = Category;