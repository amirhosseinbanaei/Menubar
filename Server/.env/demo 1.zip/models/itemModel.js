const mongoose = require('mongoose');
const Category = require('./categoryModel');
const User = require('./../models/userModel');
const translationSchema = new mongoose.Schema({
   name: { type: String, trim: true },
   cardDescription: { type: String, trim: true },
});

const itemSchema = new mongoose.Schema({
   fa: translationSchema,
   en: translationSchema,
   category: {
      type: mongoose.Schema.Types.ObjectId,
      ref: Category,
   },
   price: {
      type: Number,
      required: true,
      trim: true
   },
   discount: {
      type: Number,
      default: 0,
      trim: true,
   },
   available: {
      type: Boolean,
      required: true,
      default: true
   },
   hideItem: {
      type: Boolean,
      required: true,
      default: false
   },
   subCategory: {
      type: String,
      required: true,
   },
   image: {
      type: String,
      required: true,
   },
   project: {
      type: String,
      required: true
   },
   ratings: [
      {
         user: {
            type: mongoose.Schema.Types.ObjectId,
            ref: User,
            required: true,
         },
         rating: {
            type: Number,
            min: 1,
            max: 5,
            required: true,
         },
      },
   ],
   tags: Array
});

const Item = mongoose.model('items', itemSchema);

module.exports = Item;