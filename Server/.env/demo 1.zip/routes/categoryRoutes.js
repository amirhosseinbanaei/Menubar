const express = require('express');
const router = express.Router();
const controller = require('./../controllers/category');

router
   .route('/')
   .get(controller.getCategories)

router
   .route('/add')
   .post(controller.createCategory);

router
   .route('/subcategory')
   .delete(controller.deleteSubCategory);

router
   .route('/:categoryId')
   .get(controller.getCategory)
   .put(controller.editCategory)
   .delete(controller.deleteCategory);

module.exports = router;