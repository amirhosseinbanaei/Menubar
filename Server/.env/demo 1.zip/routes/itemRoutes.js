const express = require('express');
const router = express.Router();
const controller = require('./../controllers/item');
const resizeImage = require('./../middlewares/resizeImage');
const uploadToFTP = require('./../middlewares/ftpUpload');
router
   .route('/')
   .get(controller.getItems);

router
   .route('/add')
   .post(controller.addItem);

router
   .route('/add/excel-file')
   .post(controller.uploadExcel, controller.addItemWithExcel);

router
   .route('/:itemId')
   .get(controller.getSingleItem)
   .delete(controller.deleteItem)
   .put(controller.editItem);

router
   .route('/:itemId/rate')
   .post()


module.exports = router;