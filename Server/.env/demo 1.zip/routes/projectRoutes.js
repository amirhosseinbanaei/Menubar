const express = require("express");
const controller = require("../controllers/project");

const router = express.Router();

router.route('/create').post(controller.createProject);
router
   .route('/:projectName')
   .put(controller.updateProject)
   .get(controller.getProject);
module.exports = router;