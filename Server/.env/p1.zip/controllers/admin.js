const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const fs = require('fs');
const Admin = require("../models/adminModel");

const signToken = (userId, secretKey, expireTime) => {
   return jwt.sign({ userId }, process.env[secretKey], { expiresIn: `${expireTime}` });
}

exports.register = async (req, res) => {
   const { fullName, project, projectFa, domain, email, phoneNumber, password, plan, role } = req.body;

   try {
      const hashedPassword = await bcrypt.hash(password, 10);
      const admin = await Admin.create({
         fullName,
         email,
         phoneNumber,
         password: hashedPassword,
         project,
         projectFa,
         plan,
         domain,
         role
      });

      const accessToken = signToken(admin._id, 'JWT_SECRET_ACCESSTOKEN', '1d');
      const refreshToken = signToken(admin._id, 'JWT_SECRET_REFRESHTOKEN', '7d');

      res.cookie('accessToken', accessToken, { httpOnly: true, expire: '1d' });
      res.cookie('refreshToken', refreshToken, { httpOnly: true });

      return res.status(201).json({ status: 'success', message: 'ادمین جدید اضافه شد .' });
   } catch (error) {
      return res.status(500).json({ status: 'failed', message: 'در فرآیند ثبت نام خطایی رخ داد !', error });
   }
};

exports.login = async (req, res) => {
   const { email, password } = req.body;

   const admin = await Admin.findOne({ email });

   if (!admin) {
      return res.status(401).json({ message: "کاربری با این ایمیل وجود ندارد" });
   }

   const isPasswordValid = await bcrypt.compare(password, admin.password);

   if (!isPasswordValid) {
      return res.status(401).json({ message: "پسورد وارد شده صحیح نیست" });
   }

   const adminObject = admin.toObject();

   Reflect.deleteProperty(adminObject, "password");
   Reflect.deleteProperty(adminObject, "phoneNumber");

   const accessToken = signToken(admin._id, 'JWT_SECRET_ACCESSTOKEN', '1d');
   const refreshToken = signToken(admin._id, 'JWT_SECRET_REFRESHTOKEN', '7d');

   res.cookie('accessToken', accessToken, { httpOnly: true, expire: '1d' });
   res.cookie('refreshToken', refreshToken, { httpOnly: true });

   return res.json({ ...adminObject });
};