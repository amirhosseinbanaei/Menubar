const fs = require('fs');
const path = require('path');
const Category = require('./../models/categoryModel');
const multerStorage = require('./../utils/multerStorage');
const ftpDeleteHandler = require('./../middlewares/ftpUpload');
const upload = multerStorage('category');
exports.upload = upload.single('category-image');

exports.createCategory = async (req, res) => {
   if (req.file && req.resizedImagePath) {
      fs.rm(path.join(__dirname, `../uploads/category/${req.file.originalname}`), err => {
         if (err) {
            console.log(err)
         }
      });
      fs.rm(`${req.resizedImagePath}`, err => err && console.log(err));
   }
   try {
      const newCategory = {
         image: req.finalImageName ? `https://ftp-menubar.amirhosseinbanaei.ir/admin-ftp-menubar${req.finalImageName}` : ' ',
         project: req.headers.project
      };

      if (req.body.enName) {
         newCategory.en = {
            name: req.body.enName,
            subCategory: req.body.enSubCategory
         };
      }

      if (req.body.faName) {
         newCategory.fa = {
            name: req.body.faName,
         };
      }

      if (req.body.arName) {
         newCategory.ar = {
            name: req.body.arName,
         };
      }

      await Category.create(newCategory);

      res
         .status(201)
         .json({
            status: "success",
            message: "دسته بندی با موفقیت ایجاد شد"
         })
   } catch (err) {
      console.log(err)
      res
         .status(404)
         .json({
            status: "failed",
            message: "ساخت دسته بندی با مشکل مواجه شد"
         })
   }
};

exports.editCategory = async (req, res) => {
   if (req.file && req.resizedImagePath) {
      fs.rm(path.join(__dirname, `../uploads/category/${req.file.originalname}`), err => {
         if (err) {
            console.log(err)
         }
      });
      fs.rm(`${req.resizedImagePath}`, err => err && console.log(err));
   }
   const category = await Category.findOne({
      _id: req.body.id,
      project: req.headers.project
   });
   if (!category) {
      return res.status(404).json({ status: 'failed', message: "دسته بندی یافت نشد" });
   }
   if (req.finalImageName) {
      ftpDeleteHandler(category.image)
   }
   const updateData = {
      name: req.body.name ? req.body.name : category.name,
      image: req.finalImageName ? `https://ftp-menubar.amirhosseinbanaei.ir/admin-ftp-menubar${req.finalImageName}` : category.image,
   }
   try {
      await Category.findOneAndUpdate({ _id: req.body.id, restaurantName: req.headers.restaurantname }, updateData);
      return res.status(200).json({ status: 'success', message: "دسته بندی با موفقیت ویرایش شد ." });
   } catch (error) {
      return res.status(404).json({ status: 'failed', message: "ویرایش دسته بندی با خطا مواجه شد !" });
   }
};

exports.deleteCategory = async (req, res) => {
   const deleteCategory = await Category.findOneAndRemove({
      name: req.params.name,
      restaurantName: req.headers.restaurantname
   });
   if (!deleteCategory) {
      return res.status(404).json({ status: 'failed', message: "دسته بندی یافت نشد !" });
   }
   return res.status(200).json({ status: 'success', message: "دسته بندی با موفقیت حذف شد!" });
};

exports.getCategory = async (req, res) => {
   const category = await Category.findOne({
      name: req.params.categoryName,
      project: req.headers.project
   });
   if (!category) {
      return res.status(404).json({ status: 'failed', message: "دسته بندی یافت نشد !" });
   }
   return res.status(200).json(category);
};

exports.getCategories = async (req, res) => {
   const categories = await Category.find({ project: req.headers.project });
   res
      .status(200)
      .json({
         status: 'success',
         length: categories.length,
         categories
      })
};
