const fs = require('fs');
const path = require('path');
const Item = require('./../models/itemModel');
const Amir = require('./../models/amirModel');
const multerStorage = require('./../utils/multerStorage');
const ftpDeleteHandler = require('./../middlewares/ftpUpload');
const upload = multerStorage('item');
exports.upload = upload.single('item-image');

exports.getItemsOld = async (req, res) => {
   const { project } = req.headers
   try {
      const getItems = await Item.find({ project }).populate('category');
      return res.status(200).json({
         length: getItems.length,
         getItems
      });
   } catch (error) {
      res.status(404).json('مشکلی در دریافت آیتم ها رخ داد')
   }
}

exports.getItem = async (req, res) => {
   const { project } = req.headers;
   console.log(req.params)
   const getItem = await Item.findOne({
      name: req.params.itemName,
      project
   }).populate('category', 'name');
   if (!getItem) {
      return res.status(404).json({ status: 'failed', message: "آیتم یافت نشد !" });
   }
   return res.status(200).json(getItem);
};

exports.createItemOld = async (req, res) => {
   if (req.file && req.resizedImagePath) {
      fs.rm(path.join(__dirname, `../uploads/item/${req.file.originalname}`), err => {
         if (err) {
            console.log(err)
         }
      });
      fs.rm(`${req.resizedImagePath}`, err => err && console.log(err));
   }
   try {
      await Item.create({
         name: req.body.name,
         image: `https://ftp-menubar.amirhosseinbanaei.ir/admin-ftp-menubar${req.finalImageName}`,
         category: req.body.category,
         price: req.body.price,
         status: true,
         cardDescription: req.body.cardDescription,
         project: req.headers.project
      });
      res
         .status(200)
         .json({
            status: "success",
            message: "آیتم جدید با موفقیت ایجاد شد"
         })
   } catch (err) {
      console.log(err)
      res
         .status(404)
         .json({
            status: "failed",
            message: "ساخت آیتم با مشکل مواجه شد !"
         })
   }
};

exports.createItem = async (req, res) => {
   if (req.file && req.resizedImagePath) {
      fs.rm(path.join(__dirname, `../uploads/item/${req.file.originalname}`), err => {
         if (err) {
            console.log(err)
         }
      });
      fs.rm(`${req.resizedImagePath}`, err => err && console.log(err));
   }
   try {
      const newItemData = {
         image: req.finalImageName ? `https://ftp-menubar.amirhosseinbanaei.ir/admin-ftp-menubar${req.finalImageName}` : ' ',
         category: req.body.category,
         status: true,
         project: req.headers.project
      };

      if (req.body.enName) {
         newItemData.en = {
            name: req.body.enName,
            price: req.body.enPrice || 0,
            cardDescription: req.body.enCardDescription || null,
            subCategory: req.body.enSubCategory || null
         };
      }

      if (req.body.faName) {
         newItemData.fa = {
            name: req.body.faName,
            price: req.body.faPrice || 0,
            cardDescription: req.body.faCardDescription || null // Set to null if not available
         };
      }

      if (req.body.arName) {
         newItemData.ar = {
            name: req.body.arName,
            price: req.body.arPrice || 0,
            cardDescription: req.body.arCardDescription || null // Set to null if not available
         };
      }

      await Item.create(newItemData);
      res
         .status(200)
         .json({
            status: "success",
            message: "آیتم جدید با موفقیت ایجاد شد"
         })
   } catch (err) {
      console.log(err)
      res
         .status(404)
         .json({
            status: "failed",
            message: "ساخت آیتم با مشکل مواجه شد !"
         })
   }
};

exports.getItems = async (req, res) => {
   const { project } = req.headers
   try {
      const getItems = await Item.find({ project }).populate('category');
      return res.status(200).json({
         length: getItems.length,
         getItems
      });
   } catch (error) {
      res.status(404).json('مشکلی در دریافت آیتم ها رخ داد')
   }
}

exports.editFood = async (req, res) => {
   if (req.file && req.resizedImagePath) {
      fs.rm(path.join(__dirname, `../../upload/food/${req.file.originalname}`), err => {
         if (err) {
            console.log(err)
         }
      });
      fs.rm(`${req.resizedImagePath}`, err => err && console.log(err));
   }
   const food = await Food.findOne({
      _id: req.body.id,
      restaurantName: req.headers.restaurantname
   }).populate('category');
   if (!food) {
      return res.status(404).json({ status: 'failed', message: "غذا یافت نشد !" });
   }
   if (req.finalImageName) {
      ftpDeleteHandler(food.image)
   }
   const updateData = {
      image: req.finalImageName ? `https://ftp-menubar.amirhosseinbanaei.ir/admin-ftp-menubar${req.finalImageName}` : food.image,
      name: req.body.name ? req.body.name : food.name,
      category: req.body.category ? req.body.category : food.category,
      price: req.body.price ? req.body.price : food.price,
      cardDescription: req.body.cardDescription ? req.body.cardDescription : food.cardDescription,
      description: req.body.description ? req.body.description : food.description,
   }
   try {
      await Food.findOneAndUpdate({ _id: req.body.id, restaurantName: req.headers.restaurantname }, updateData);
      return res.status(200).json({ status: 'success', message: "غذا با موفقیت ویرایش شد ." });
   } catch (error) {
      return res.status(404).json({ status: 'failed', message: "ویرایش غذا با خطا مواجه شد !" });
   }
};

exports.deleteFood = async (req, res) => {
   const deleteFood = await Food.findOneAndRemove({
      name: req.params.foodName,
      restaurantName: req.headers.restaurantname
   });
   if (!deleteFood) {
      return res.status(404).json({ status: 'failed', message: "غذا یافت نشد !" });
   }
   return res.status(200).json({ status: 'success', message: "غذا با موفقیت حذف شد !" });
};