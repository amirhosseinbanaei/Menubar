const Order = require('./../models/orderModel');

exports.getOrders = async (req, res) => {
   const { userId } = req.params;
   try {
      const orders = await Order.findOne({ userId }).select('items');
      return res.status(200).json(orders);
   } catch (error) {
      return res.status(404).json('خطایی در دریافت سفارشات پیش آمد');
   }
}