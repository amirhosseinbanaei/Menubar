const fs = require('fs');
const Project = require('../models/projectModel');
exports.createProject = async (req, res) => {
   try {
      const newProjectData = await Project.create({
         name: req.headers.project,
         languages: req.body.languages,
         about: req.body.about
      });
      fs.writeFile('./data.js', JSON.stringify(`export default ${JSON.stringify(newProjectData)};`), (err) => {
         console.log(err)
      });
      res
         .status(200)
         .json({
            status: "success",
            message: "ساختار پروژه با موفقیت ایجاد شد"
         })
   } catch (err) {
      console.log(err)
      res
         .status(404)
         .json({
            status: "failed",
            message: "ساخت ساختار پروژه با مشکل مواجه شد !"
         })
   }
};