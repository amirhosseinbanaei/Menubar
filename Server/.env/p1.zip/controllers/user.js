const User = require('./../models/userModel');
const jwt = require('jsonwebtoken');

const signToken = (userId, secretKey, expireTime) => {
   return jwt.sign({ userId }, process.env[secretKey], { expiresIn: `${expireTime}` });
}

exports.register = async (req, res) => {
   const { phoneNumber } = req.body;
   console.log(phoneNumber);
   const api = Kavenegar.KavenegarApi({ apikey: '6368597749757365674F34677A7956466C505058426B53487069466A48317A77636F486954496C542F59733D' });
   api.Send({ message: "خدمات پیام کوتاه کاوه نگار", sender: "1000689696", receptor: "09196535654" });
   res.status(200).json('پیامک ارسال شد');

}

exports.completeRegister = async (req, res) => {
   const { phoneNumber, fullName } = req.body;
   try {
      const user = await User.create({
         fullName,
         phoneNumber,
      });

      const accessToken = signToken(user._id, 'JWT_SECRET_ACCESSTOKEN', '1d');
      const refreshToken = signToken(user._id, 'JWT_SECRET_REFRESHTOKEN', '7d');

      res.cookie('accessToken', accessToken, { httpOnly: true, expire: '1d' });
      res.cookie('refreshToken', refreshToken, { httpOnly: true });

      return res.status(201).json({ status: 'success', message: 'حساب شما با موفقیت ایجاد شد', user });
   } catch (error) {
      return res.status(500).json({ status: 'failed', message: 'در فرآیند ثبت نام خطایی رخ داد', error });
   }
};

exports.login = async (req, res) => {
   const { phoneNumber } = req.body;

   const user = await User.findOne({ phoneNumber });

   if (!user) {
      return res.status(401).json({ message: "کاربری با این شماره همراه وجود ندارد" });
   }

   try {
      const userObject = user.toObject();

      Reflect.deleteProperty(userObject, "password");
      Reflect.deleteProperty(userObject, "phoneNumber");

      const accessToken = signToken(user._id, 'JWT_SECRET_ACCESSTOKEN', '1d');
      const refreshToken = signToken(user._id, 'JWT_SECRET_REFRESHTOKEN', '7d');

      res.cookie('accessToken', accessToken, { httpOnly: true, expire: '1d' });
      res.cookie('refreshToken', refreshToken, { httpOnly: true });

      return res.status(201).json({ status: 'success', message: 'با موفقیت به حساب خود وارد شدید', user });
   } catch (error) {
      return res.status(500).json({ status: 'failed', message: 'در فرآیند ورود خطایی رخ داد', error });
   }
};