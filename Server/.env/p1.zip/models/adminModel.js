const mongoose = require('mongoose');
const Schema = new mongoose.Schema({
   fullName: {
      type: String,
      required: true
   },
   domain: {
      type: String,
      required: true
   },
   email: {
      type: String,
      required: true,
      lowercase: true
   },
   phoneNumber: {
      type: String,
      required: true,
   },
   password: {
      type: String,
      required: true,
   },
   project: {
      type: String,
      required: true
   },
   projectFa: {
      type: String,
      required: true
   },
   plan: {
      type: String,
      required: true
   },
   role: {
      type: String,
      enum: ['ADMIN', 'EDITOR'],
      default: 'ADMIN',
   },
})

const SubmitedAdmin = mongoose.model('admins', Schema);
module.exports = SubmitedAdmin;