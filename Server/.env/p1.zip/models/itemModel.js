const mongoose = require('mongoose');
const Category = require('./categoryModel');

const translationSchema = new mongoose.Schema({
   name: { type: String, trim: true },
   cardDescription: { type: String, trim: true },
   price: { type: Number, required: true, trim: true },
   subCategory: { type: String }
});

const itemSchema = new mongoose.Schema({
   fa: translationSchema,
   en: translationSchema,
   ar: translationSchema,
   price: translationSchema,
   category: {
      type: mongoose.Schema.Types.ObjectId,
      ref: Category,
   },
   discount: {
      type: Number,
      default: 0,
      trim: true,
   },
   status: {
      type: Boolean,
      required: true,
   },
   image: {
      type: String,
      required: true,
   },
   project: {
      type: String,
      required: true
   },
});

const Item = mongoose.model('items', itemSchema);

module.exports = Item;