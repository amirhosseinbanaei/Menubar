const mongoose = require("mongoose");

const schema = new mongoose.Schema({
   items: Array,
   status: {
      type: Boolean,
      default: false
   },
   authority: {
      type: String,
      required: true
   },
   userId: {
      type: String,
      required: true
   },
   createdAt: {
      type: Date,
      required: true
   }
}
);

const Order = mongoose.model("orders", schema);

module.exports = Order;