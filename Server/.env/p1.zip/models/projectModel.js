const mongoose = require('mongoose');

const projectSchema = new mongoose.Schema({
   name: {
      type: String,
      required: true,
   },
   languages: {
      type: Array,
      required: true
   },
   about: {
      type: String,
      required: true,
      trim: true,
   },
   address: {
      type: String,
      trim: true,
   },
   theme: {
      primaryBackground: String,
      primary300: String,
      primary500: String,

      typographyWhite: String,
      typographyNavbar: String,
      typographyHerosection: String,
      typography500: String,
      typography700: String,

      inputBackground: String,
      sidebarBackground: String,
      border300: String,
   },
});

const Project = mongoose.model('projects', projectSchema);

module.exports = Project;