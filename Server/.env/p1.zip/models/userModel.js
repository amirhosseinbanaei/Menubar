const mongoose = require('mongoose');
const Schema = new mongoose.Schema({
   fullName: {
      type: String,
      required: true
   },
   phoneNumber: {
      type: String,
      required: true,
   },
   email: {
      type: String,
      lowercase: true,
      default: 'انتخاب نشده'
   },
   password: {
      type: String,
   },
})

const SubmitedUsers = mongoose.model('users', Schema);
module.exports = SubmitedUsers;