const express = require('express');
const router = express.Router();
const controller = require('./../controllers/category');
const resizeImage = require('./../middlewares/resizeImage');
const uploadToFTP = require('./../middlewares/ftpUpload');
router
   .route('/')
   .get(controller.getCategories)

router
   .route('/add')
   .post(controller.upload, resizeImage(500, 500), uploadToFTP('categories'), controller.createCategory);


router
   .route('/:categoryName')
   .get(controller.getCategory)
   .delete(controller.deleteCategory)


module.exports = router;