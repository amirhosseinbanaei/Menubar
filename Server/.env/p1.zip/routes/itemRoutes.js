const express = require('express');
const router = express.Router();
const controller = require('./../controllers/item');
const resizeImage = require('./../middlewares/resizeImage');
const uploadToFTP = require('./../middlewares/ftpUpload');
router
   .route('/')
   .get(controller.getItems)

router
   .route('/add')
   .post(controller.upload, resizeImage(500, 500), uploadToFTP('item'), controller.createItem);

// router
//    .route('/addn')
//    .get(controller.getItemsNew)
//    .post(controller.upload, resizeImage(500, 500), uploadToFTP('item'), controller.createItemNew);

// router
//    .route('/edit')
//    .post(foodController.upload, resizeImage(500, 500), uploadToFTP('foods'), foodController.editFood);

router
   .route('/:itemName')
   .get(controller.getItem)
   .delete(controller.deleteFood)

// router
//    .route('/:name')
//    .get(categoryController.getOneCategory)
//    .post(categoryController.upload, resizeImage, categoryController.crateCategory)
//    .delete(categoryController.deleteCategory)

// router
//    .route('/subcategories/:name')
//    .get(categoryController.getAllSubCategories)
//    .post(categoryController.crateSubCategory)
//    .delete(categoryController.removeSubCategory)
//    .patch(categoryController.editeSubCategory)

module.exports = router;