const express = require("express");
const controller = require("../controllers/project");

const router = express.Router();

router.post("/create", controller.createProject);

module.exports = router;