const express = require("express");

const controller = require("../controllers/user");

const router = express.Router();

router.post("/register", controller.register);
router.post("/complete-register", controller.completeRegister);

module.exports = router;