const express = require('express');
const router = express.Router();
const controller = require('./../controllers/category');
const isAuthenticate = require('../middlewares/isAuthenticate');
const checkSubscription = require('../middlewares/checkSubescribtion');
router
   .route('/')
   .get(checkSubscription, controller.getCategories)

router
   .route('/add')
   .post(isAuthenticate, checkSubscription, controller.addCategory);

router
   .route('/subcategory')
   .put(isAuthenticate, checkSubscription, controller.editSubCategory)
   .delete(isAuthenticate, checkSubscription, controller.deleteSubCategory)

router
   .route('/:categoryId')
   .get(checkSubscription, controller.getCategory)
   .put(isAuthenticate, checkSubscription, controller.editCategory)
   .delete(isAuthenticate, checkSubscription, controller.deleteCategory);

module.exports = router;